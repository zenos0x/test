package com.example.quicknotewidget

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private var isLoading = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.main_note_text)
        editText.setText(NoteStorage.loadNote(this))
        editText.setSelection(editText.text.length)
        isLoading = false

        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!isLoading) {
                    NoteStorage.saveNote(this@MainActivity, s?.toString() ?: "")
                }
            }
        })
    }

    override fun onPause() {
        super.onPause()
        NoteStorage.saveNote(this, editText.text.toString())
        NoteWidgetProvider.updateAllWidgets(this)
    }
}
