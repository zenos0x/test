package com.example.quicknotewidget

import android.content.Context

/**
 * All note text lives here, in plain SharedPreferences on the device.
 * No network, no account, no loading spinner - it's just a local file
 * the OS keeps for this app.
 */
object NoteStorage {
    private const val PREFS_NAME = "quick_note_prefs"
    private const val KEY_NOTE_TEXT = "note_text"

    fun loadNote(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_NOTE_TEXT, "") ?: ""
    }

    fun saveNote(context: Context, text: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_NOTE_TEXT, text).apply()
    }
}
