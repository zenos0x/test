package com.example.quicknotewidget

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

/**
 * This activity is themed to be transparent and borderless (see
 * Theme.QuickEditPopup in themes.xml). Visually it just looks like a
 * little card appearing over the home screen - the fastest approximation
 * of "type directly into the widget" that Android allows, since real
 * widgets (RemoteViews) don't support editable text fields.
 */
class QuickEditActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private var isLoading = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quick_edit)

        // Show the keyboard immediately, no extra tap needed.
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)

        editText = findViewById(R.id.quick_edit_text)
        editText.setText(NoteStorage.loadNote(this))
        editText.setSelection(editText.text.length)
        isLoading = false
        editText.requestFocus()

        // Save on every keystroke - nothing to press, nothing to load.
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!isLoading) {
                    NoteStorage.saveNote(this@QuickEditActivity, s?.toString() ?: "")
                }
            }
        })

        // Tapping the dimmed area outside the card closes the popup,
        // like dismissing a dialog.
        findViewById<View>(R.id.quick_edit_root).setOnClickListener {
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        // Belt-and-suspenders: make sure the very last keystrokes are
        // written before the popup disappears, then refresh the widget
        // on the home screen so it shows the latest text right away.
        NoteStorage.saveNote(this, editText.text.toString())
        NoteWidgetProvider.updateAllWidgets(this)
    }
}
