# Quick Note Widget

A minimal Android app whose entire purpose is the home screen widget.
Type a note, it saves instantly to local device storage, no server,
no account, no loading spinner.

## How it actually works (important)

Android's home screen widgets (`RemoteViews`) do **not** officially
support a live, typeable text field — only a fixed list of views like
`TextView`, `Button`, `ImageView`. So true "type directly inside the
widget tile" isn't something the platform allows.

This project uses the standard workaround that apps like Google Keep
use: tapping the widget opens `QuickEditActivity`, a borderless,
transparent activity themed to look like a small card floating over
the home screen (see `Theme.QuickEditPopup` in `themes.xml`). It opens
almost instantly (no visible app chrome, no navigation bar changes),
the keyboard pops up immediately, every keystroke is saved to local
storage right away, and tapping outside the card closes it. From the
user's point of view it feels like editing "in place" on the home
screen.

The widget tile itself (`widget_note.xml`) just displays the current
saved text and refreshes the moment you close the popup.

## Where the note is stored

`NoteStorage.kt` — plain `SharedPreferences`, which Android stores as
a local XML file in the app's private storage
(`/data/data/com.example.quicknotewidget/shared_prefs/`). No network
calls anywhere in this project.

## Project structure

```
QuickNoteWidget/
  app/
    src/main/
      AndroidManifest.xml
      java/com/example/quicknotewidget/
        MainActivity.kt          -> full-screen editor, opened from app icon
        QuickEditActivity.kt     -> the floating popup editor opened from the widget
        NoteWidgetProvider.kt    -> the widget itself
        NoteStorage.kt           -> save/load note text locally
      res/
        layout/
          activity_main.xml
          activity_quick_edit.xml
          widget_note.xml
        values/
          strings.xml
          themes.xml
        drawable/
          quick_edit_card_bg.xml
          widget_background.xml
        xml/
          note_widget_info.xml   -> widget size/behavior config
```

## How to build and run it

1. Install [Android Studio](https://developer.android.com/studio) if
   you don't have it.
2. Open Android Studio -> **Open** -> select the `QuickNoteWidget`
   folder (the one containing this README).
3. Let Gradle sync (it will auto-generate the Gradle wrapper files —
   you don't need to add them yourself).
4. Run the app on an emulator or a real device (▶ button).
5. On the device: long-press the home screen -> **Widgets** ->
   find **Quick Note** -> drag it onto the home screen.
6. Tap the widget, type, tap outside the card to close it. Your text
   is saved and shows on the tile.

## Customizing it further

- **Multiple notes / a notes list** — right now it's a single note,
  like a sticky note. To support several notes you'd store a list
  (e.g. as JSON in `SharedPreferences`, or move to a small Room
  database) and add a note picker to `MainActivity`.
- **Widget appearance** — colors and corner radius live in
  `widget_background.xml` and `quick_edit_card_bg.xml`.
- **Auto-save delay** — currently saves on every keystroke, which is
  simple and safe for short notes. For longer notes you could debounce
  saves (e.g. save 300ms after the user stops typing) to reduce disk
  writes.
- **App icon** — none is set (the manifest omits `android:icon`), so
  it'll use the default system icon. Add your own by generating an
  icon set in Android Studio (**File -> New -> Image Asset**) and
  referencing it in `AndroidManifest.xml`.
